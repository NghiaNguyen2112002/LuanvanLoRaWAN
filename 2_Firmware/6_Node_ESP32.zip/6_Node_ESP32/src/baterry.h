#ifndef _BATTERY_H_
#define _BATTERY_H_


#include <Arduino.h>
#include "pin.h"

#include <driver/adc.h>

#define CALIB_VOL2          (12530)
#define CALIB_ADC2          (2711)

#define CALIB_VOL1          (4340)     
#define CALIB_ADC1          (2070)       

#define PIN_LEVEL_LOW           (5000)
#define PIN_LEVEL_FULL          (8400)


void BAT_Init(uint8_t pinBat);
uint16_t BAT_GetBat(void);

#endif // !_BATTERY_H_