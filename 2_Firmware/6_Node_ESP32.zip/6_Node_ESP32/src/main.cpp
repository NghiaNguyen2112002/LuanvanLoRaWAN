#include <Arduino.h>
#include <esp_task_wdt.h>


#include "Lorawan.h"
#include "pin.h"
#include "relay.h"
#include "sensor_read.h"
#include "baterry.h"

#define WDT_TIMEOUT                 65

#define LORAWAN_BAUDRATE            115200

#define TIME_READ_SENSOR            120000
#define MAINLOOP_FRE                50

static unsigned long previousMillis = 0; 
static const long interval = 5000;
 
static int time_now;
static uint32_t timeCnt, timeSent;

static String strSer;
static uint8_t flagUplinkRL;
static char buffUplink[200];

static float temp, humi;

void setup() {
  uint8_t cnt;

  Serial1.begin(LORAWAN_BAUDRATE, SERIAL_8N1, PIN_LORA_TX, PIN_LORA_RX);
  Serial.begin(LORAWAN_BAUDRATE);

  pinMode(PIN_BT, INPUT_PULLUP);
  pinMode(PIN_LED, OUTPUT);
  BAT_Init(PIN_ADC_BAT);
  RL_Init();
  SR_Init(PIN_RS485_TX, PIN_RS485_RX, 9600);
  
  delay(1000);


  while(LRW_IsDeviceConnected() != 1);
  Serial.println("LORAWAN Device connected");
  
  cnt = 0;
  while(cnt-- > 0){
    Serial.println("Start Init Module!");
    delay(500);
    RL_Toggle(0);
    RL_Toggle(1);
    RL_Toggle(2);
    RL_Toggle(3);
  }

  RL_SetState(0, 0);
  RL_SetState(1, 0);
  RL_SetState(2, 0);
  RL_SetState(3, 0);

  while(0){
    SR_GetHumiTemp(&temp, &humi);  
    Serial.print("Temp: "); Serial.println(temp);
    Serial.print("Humi: "); Serial.println(humi);
    Serial.print("Battery: "); Serial.println(BAT_GetBat());
    delay(2000);
  }


  // LRW_Init(PIN_LORA_TX, PIN_LORA_RX, LORAWAN_BAUDRATE);

  LRW_StartJoin();
  
  esp_task_wdt_init(WDT_TIMEOUT, true); //enable panic so ESP32 restarts
  esp_task_wdt_add(NULL); //add current thread to WDT watch
  
  Serial.println("/************ BEGIN ************/");

}

void loop() {
  while(millis() - time_now < MAINLOOP_FRE);
  esp_task_wdt_reset();

  int dmy = (millis() - time_now) / MAINLOOP_FRE;
  time_now = millis();

  if(timeSent > dmy){
    timeSent -= dmy;
  }
  else {
    timeSent = 0;
  }

  if(digitalRead(PIN_BT) == 0){
    timeSent = 0;
  }

  if(timeSent == 0){
    timeSent = TIME_READ_SENSOR / MAINLOOP_FRE;
    
    RL_SetState(0, 1);


    while(SR_GetHumiTemp(&temp, &humi) == 0){
      delay(2000);
    }

    RL_SetState(0, 0);

    Serial.print("Temp: "); Serial.println(temp);
    Serial.print("Humi: "); Serial.println(humi);
    Serial.print("Battery: "); Serial.println(BAT_GetBat());

    sprintf(buffUplink, "{\"air\":{\"temp\":%.02f,\"humi\":%.02f},\"relay\":{\"RL1\":%d,\"RL2\":%d,\"RL3\":%d,\"RL4\":%d}, \"bat\":%d}",
      temp, humi, RL_GetState(0), RL_GetState(1), RL_GetState(2), RL_GetState(3), BAT_GetBat()
    );  

    LRW_SendMsg(1, 15, buffUplink);
  }

  if(Serial1.available()){
    strSer = Serial1.readString();

    Serial.print("LORA: "); Serial.println(strSer);

    if(strSer.indexOf("OK+RECV") != -1){

      if(strSer.indexOf("A1") != -1){
        flagUplinkRL = 1;
        Serial.println("Relay 1 Off!");
        RL_SetState(0, 0);
      }
      else if(strSer.indexOf("A2") != -1){
        flagUplinkRL = 1;
        Serial.println("Relay 2 Off!");
        RL_SetState(1, 0);
      }
      else if(strSer.indexOf("A3") != -1){
        flagUplinkRL = 1;
        Serial.println("Relay 3 Off!");
        RL_SetState(2, 0);
      }
      else if(strSer.indexOf("A4") != -1){
        flagUplinkRL = 1;
        Serial.println("Relay 4 Off!");
        RL_SetState(3, 0);
      }
      else if(strSer.indexOf("B1") != -1){
        flagUplinkRL = 1;
        Serial.println("Relay 1 On!");
        RL_SetState(0, 1);
      }
      else if(strSer.indexOf("B2") != -1){
        flagUplinkRL = 1;
        Serial.println("Relay 2 On!");
        RL_SetState(1, 1);
      }
      else if(strSer.indexOf("B3") != -1){
        flagUplinkRL = 1;
        Serial.println("Relay 3 On!");
        RL_SetState(2, 1);
      }
      else if(strSer.indexOf("B4") != -1){
        flagUplinkRL = 1;
        Serial.println("Relay 4 On!");
        RL_SetState(3, 1);
      }

    }
    else if(strSer.indexOf("ERR+SENT") != -1){
      LRW_StartJoin();
    }
  }

  if(Serial.available()){
    strSer = Serial.readString();
    Serial.print("Received: "); Serial.println(strSer);

    if(strSer.indexOf("AT") != -1){
      SendCMD(strSer);
    }
    else {
      Serial.print("MSG: "); Serial.println(LRW_SendMsg(1, 15, strSer));
    }
    
  }

  if(flagUplinkRL){
    flagUplinkRL = 0;
    sprintf(buffUplink, "{\"relay\":{\"RL1\":%d,\"RL2\":%d,\"RL3\":%d,\"RL4\":%d}}", RL_GetState(0), RL_GetState(1), RL_GetState(2), RL_GetState(3));
    LRW_SendMsg(1, 15, buffUplink);

  }

}

